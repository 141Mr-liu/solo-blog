title: Docker下操作应用，设置Mysql的外网也可访问的权限。
date: '2019-11-06 18:42:34'
updated: '2019-11-06 21:49:35'
tags: [Docker, 服务器, Mysql]
permalink: /articles/2019/11/06/1573036954887.html
---
#####
 众所周知，Docker 是一款容器平台，安装在 Docker 下的所有应用，都以容器的形式存在，也就是说，我们无法在正常的 Linux 或 Unix 文件系统下去操作应用。那么，我们应该如何去管理安装在Docker下的应用（准确的说应该是容器）呢？本篇文章以mysql为例，记录下通过Docker操作Mysql数据库以实现外网访问权限。
#####
1、```docker ps```指令
	```docker ps``` 指令可以查看当前运行状态下的应用运行情况。使用Docker ps命令获取Mysql的ID。
![image.png](https://img.hacpai.com/file/2019/11/image-5c8f702f.png)
通过docker ps指令获取到了Mysql 的ID为 6154c5ef7864 。

2、docker exec 指令
我们可以通过 ```docker exec -it 应用ID或应用名 /bin/bash ``` 的指令来进入应用容器。
参数说明：
* **-i**: 交互式操作。
* **-t**: 终端。
* **应用ID或应用名**: 容器的ID，如刚刚通过docker获取的mysql的容器d为 6154c5ef7864、或直接输入mysql
* **/bin/bash**：放在容器名后的是命令，这里我们希望有个交互式 Shell，因此用的是 /bin/bash。
示例：```docker exec -it 6154c5ef7864 /bin/bash```
``` docker exec -it mysql bash```

3、连接Mysql
进入Mysql的容器后，便可以直接通过 
```mysql -uroot -p ``` 指令，根据提示输入密码后，进入mysql交互界面

4、设置外网访问权限：
通过指令
```GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'liuxin' WITH GRANT OPTION;```
来创建 用户名为 root 密码为 liuxin 可以从任意主机（@）连接到数据库。
运行结束后通过指令：``` flush privileges; ```来刷新数据库配置。

5、退出容器：
配置完成后可以接通过```exit```退出Mysql以及Docker容器

