title: 【大数据从入门到放弃】1、Hadoop集群环境搭建（上）
date: '2019-11-19 20:10:08'
updated: '2019-11-19 20:10:08'
tags: [Hadoop, 大数据, MapReduce, 大数据从入门到放弃]
permalink: /articles/2019/11/19/1574165408089.html
---
本文仅讲解 Hadoop 的搭建步骤中的节点基础配置，基础的理论知识不做阐述

### 1、CentOS 的下载及安装

本次实验使用的 CentOS 版本为 Centos6

* 下载 Centos6 系统镜像
* 新建虚拟机，设置 ISO 为镜像文件
* 设置虚拟机的配置（本次实验需要 3 台虚拟机，如何配置看自己电脑顶部顶得住 ~）
* 打开虚拟机，傻瓜式安装 不做讲解，
* 设置主机名为 Hadoop1

### 2、创建文件夹

因为这三个文件夹后续三台虚拟机都会使用，所以在克隆前创建
`mkdir /export/data/`  data 文件夹用于存放数据类文件
`mkdir /export/servers/`  servers 文件夹用于存放服务类软件，如 JDK，Hadoop 等
`mkdir /export/software/`  software 文件夹用于存放安装包文件，如 JDK 的压缩包、Hadoop 的压缩包等

### 3、克隆虚拟机

创建好文件夹之后，我们需要创建多个虚拟机，本次实验使用了三个节点，因此我们需要创建三个虚拟机，算上已经创建好的虚拟机，还需创建两个虚拟机，为了快速创建和后续的方便管理，我们使用克隆虚拟机快速创建多个虚拟机。

1. 完全关闭 Hadoop1 虚拟机
2. 选择 Hadoop1 虚拟机，点击 VM 上方的虚拟机选项卡
3. 点击 虚拟机 -&gt; 管理 -&gt; 克隆
4. 选择完全克隆
5. 分别克隆出 Hadoop2 和 Hadoop3 两台虚拟机

### 3、节点网络配置

打开 Hadoop1、Hadoop2、Hadoop3 三个虚拟机。
进行以下配置：

#### 1. 配置主机名

在三个节点中分别打开 network 文件，`vi /etc/sysconfig/network` 在 HOSTNAME 分别设置为节点名：Hadoop1、Hadoop2、Hadoop3

#### 2.配置虚拟机网卡

由于虚拟机克隆的原因，在 Hadoop2 和 Hadoop3 中会出现两块网卡，因此我们需要删除一块网卡
在 Hadoop2 和 Hadoop3 中打开`70-persistent-net.rules` 文件，`vi /etc/udev/rules.d/70-persistent-net.rules`，删除 eth1 网卡的相关配置。

### 4、配置 IP 地址

我们此时三台虚拟机的 IP 地址默认都是自动获取的，因此在重启虚拟机时，可能 IP 地址会发生变化，这样，Hadoop 集群便无法正常使用。因此，我们通过一下配置来配置静态 IP 地址。

#### 1.确认当前 IP 网段、网关等参数

通过`ifconfig`指令查看 IP 地址。

#### 2.设置静态 IP

设置静态 IP 可以通过一下两种方法实现：

##### 1.图形化界面实现

点击虚拟机右上方的网络图标，选择需要设置的网卡（目前只剩 eth0），设置 IP 地址为静态 IP，将 IP 地址、网关、子网掩码等参数填入相应位置。

##### 2.通过修改配置文件实现
* 打开`ifcfg-eth0`文件（当前网卡文件），`vi /etc/sysconfig/network-scripts/ifcfg-eth0`
* 将BOOTPROTO设置为static  `BOOTPROTO=static`静态IP
* 添加以下配置
```
IPADDR=192.168.49.131 
GATEWAY=192.168.49.2
NETMASK=255.255.255.0
DNS1=8.8.8.8

```
其中，IP地址和网关、子网掩码根据自己的实际情况设置

#### 3.IP地址配置完成
分别对Hadoop1、Hadoop2、Hadoop3进行以上配置，注意IP地址不能一致。

#### 4.验证网络流通性
在Hadoop1分别使用`ping`指令检查网络流通性。

#### 5.配置IP映射
分别在Hadoop1、Hadoop2、Hadoop3做一下配置
* 打开`hosts`文件,`vi /etc/hosts`
* 在文件末尾添加以下几行配置
```
192.168.49.131 hadoop1
192.168.49.132 hadoop2
192.168.49.133 hadoop3

```
其中，IP地址分别为节点对应的IP地址。
#### 6.验证IP映射
分别在Hadoop1、Hadoop2、Hadoop3中使用ping：
```
ping Hadoop1
ping Hadoop2
ping Hadoop3

```
查看是否能成功PING到对应的节点。

### 5.配置SSH以及SSH免密登录
#### 1.检查SSH服务安装
使用 `rpm -qa | grep ssh`指令查看SSH服务是否安装
若未安装SSH服务，则可通过yum安装进行安装 `yum install ssh`
#### 2.检查SSH服务是否启动
使用 `ps -qa | grep ssh`指令查看SSH服务是否启动
若为启动，可使用service指令进行启动 `service start ssh`
#### 3.配置Hadoop1到Hadoop2、Hadoop3的单项免密登录
* 在Hadoop1主节点上使用 `ssh-keygen -t rsa`指令生成一个密钥。
* 使用指令 `ssh-copy-id Hadoop2`指令将密钥分配到Hadoop2和Hadoop3上
#### 检测免密登录
在Hadoop1上分别使用指令 `ssh Hadoop2` 和`ssh Hadoop3`对免密登录进行检测，若Hadoop1均能免密访问Hadoop2和Hadoop3，则说明免密登录配置成功。

**到此，Hadoop的基础配置结束，下篇文章讲解Hadoop集群的应用配置**
