title: 【Docker】1、Docker从安装到卸载--Dcoker的基本命令
date: '2019-11-10 21:49:15'
updated: '2019-11-10 21:49:50'
tags: [Docker, 服务器, 开发]
permalink: /articles/2019/11/10/1573393755217.html
---
本篇文章讲解从如何安装Docker到如何卸载Docker，对Docker的基本命令进行讲解。
### 1、安装Docker
安装Docker比较简单的方法就是使用yum安装，一键安装，输入指令 `yum install docker-ce`即可一键安装Docker。
* Docker-ce为社区版 免费使用
* Docker-ee为企业版 收费使用

### 2、Docker启动与停止
虽说Docker是一个容器，但是他的本质还是一个Linux的一个应用，因此我们可以通过service 和systemctl去操作Docker服务。
**启动Docker**：`systemctl start docker` 或 `service docker start`
**停止Docker**：`systemctl stop docker` 或 `service docker stop`
**重启Docker**：`systemctl restart docker` 或 `service docker restart`
**查看Docker状态**：`systemctl status docker` 或 `service docker status`
**设置Docker自启动**：`systemctl enable docker`

### 3、Docker的卸载
Docker安装完了，那么我们也该卸载它的，手动滑稽，前面说过Docker本质上还是Linux应用，因此我们也可以直接通过`yum remove docker-ce`去卸载它。
当然，你也可以通过rm-rf */ 去删除它。手动滑稽

